<?php if (isset($component)) { $__componentOriginalb525200bfa976483b4eaa0b7685c6e24 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-widgets::components.widget','data' => ['class' => 'fi-filament-info-widget']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-widgets::widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'fi-filament-info-widget']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <?php if (isset($component)) { $__componentOriginalee08b1367eba38734199cf7829b1d1e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee08b1367eba38734199cf7829b1d1e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.section.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

        <div class="fi-filament-info-widget-main">
            <a
                href="https://filamentphp.com"
                rel="noopener noreferrer"
                target="_blank"
            >
                <svg
                    aria-label="Filament"
                    fill="currentColor"
                    role="img"
                    viewBox="0 0 1988.74 399.55"
                    xmlns="http://www.w3.org/2000/svg"
                    class="fi-filament-info-widget-logo"
                >
                    <path
                        d="M115.85,138.9v-20.22c0-31.15,10.38-54.64,41.53-54.64h27.87V.1h-27.87C85.79.1,48.64,44.36,48.64,118.68v20.22H0v53.55h48.64v201.63h67.21v-201.63h82.19v-53.55h-82.19Z"
                    />
                    <rect x="382.68" y=".11" width="66.67" height="393.98" />
                    <path
                        d="M628.22,335.07c-36.62,0-70.49-27.87-70.49-68.85s33.88-68.86,70.49-68.86,69.94,24.59,69.94,68.86-33.88,68.85-69.94,68.85M698.16,170.59c-18.57-28.42-56.28-37.16-79.23-37.16-67.21,0-130.06,50.82-130.06,132.79s62.84,132.79,130.06,132.79c25.14,0,62.84-11.48,79.23-37.71v32.79h66.67v-255.2h-66.67v31.7Z"
                    />
                    <path
                        d="M1116.15,133.44c-20.22,0-56.28,6.01-80.33,48.09-14.21-31.16-40.98-45.36-81.42-47.55-24.04,0-59.01,11.48-73.22,42.63v-37.7h-66.67v255.19h66.67v-136.07c0-43.71,26.23-59.56,53.55-59.56s46.45,19.68,47,55.19v140.44h66.66v-136.07c0-38.79,21.86-59.56,51.92-59.56,27.32,0,48.09,20.22,48.09,56.83v138.8h66.12v-145.9c0-74.87-36.61-114.75-98.36-114.75"
                    />
                    <path
                        d="M1314.33,243.27c4.92-34.43,32.23-54.1,67.21-54.1,32.78,0,59.01,19.12,63.93,54.1h-131.14ZM1380.99,133.44c-72.68,0-132.24,51.91-132.24,132.24s59.56,133.87,132.24,133.87c46.99,0,96.17-18.03,119.12-61.74-16.39-8.75-34.97-18.58-50.82-27.32-12.02,21.86-38.25,32.78-63.93,32.78-37.71,0-66.12-20.76-70.49-54.64h194.53c.55-6.01,1.09-16.4,1.09-22.95,0-80.33-56.83-132.24-129.51-132.24"
                    />
                    <path
                        d="M1698.38,133.44c-29.51,0-61.75,15.84-75.96,43.17v-37.7h-66.66v255.19h66.66v-136.07c0-44.26,25.69-59.56,55.74-59.56s48.64,19.68,48.64,56.83v138.8h66.66v-150.82c0-72.13-35.51-109.84-95.08-109.84"
                    />
                    <polygon
                        points="1868.52 41.64 1868.52 138.9 1822.07 138.9 1822.07 192.45 1868.52 192.45 1868.52 394.09 1934.64 394.09 1934.64 192.45 1988.74 192.45 1988.74 138.9 1934.64 138.9 1934.64 41.64 1868.52 41.64"
                    />
                    <path
                        d="M277.05,80.43c22.95,0,42.07-17.49,42.07-40.44S300,.11,277.05.11s-43.17,17.48-43.17,39.89,19.67,40.44,43.17,40.44"
                    />
                    <path
                        d="M323.62,164.94l-40.54-24.73,2.36-20.71-42.93,1.25.26,1.6c.38,2.33.06,5.14-.29,8.12-.71,6.12-1.52,13.07,4.08,17.83,1.93,1.64,8.35,5.31,15.14,9.19,4.29,2.45,9.81,5.6,12.53,7.37-1.73.58-4.17.44-6.56.31-1.56-.09-3.15-.19-4.59-.07l-2.06.14c-6.77.44-13.01.91-14.89,1.8-3.26,1.55-4.26,8.19-3.8,13.71.23,2.77,1.22,9.52,5.54,12.25l26.35,15.94-27.62,2.43-.53.15c-2.69,1.35-3.09,6.74-3.08,9.83,0,5.09,1.15,12.03,4.67,15.03l27.31,16.82c-1.02.02-2.05.06-3.07.08-8.85.23-18.02.46-26.14,2.81l-.44.22c-2.03,1.52-2.19,11.99-.76,17.93.85,3.58,2.3,5.87,4.09,6.72l26.38,15.93-26.59,2.44-.49.13c-5.61,2.66-3.51,17.42-2.07,21.75l.23.7,30.04,19.34-26.51,1.8c-1.81.09-2.69,1.08-3.38,1.99-2.17,2.88-2.03,13.55-1.59,29.49.23,7.83.43,15.22-.06,18.24l-.36,2.25h38.49l.21-23.88,45.27-4.62.38-.04.3-.21c1.94-1.39,2.28-6.6,2.3-9.58.02-2.34-.14-10.21-3-13.37l-28.81-18.02,28.71-2.66.31-.23c2.37-1.76,2.67-12.39,1.09-18.54-.98-3.82-2.63-6.25-4.65-7.1l-26.3-15.92c2.59-.14,5.31-.21,8.12-.28,6.36-.16,12.94-.33,18.45-1.47,1.94-.41,3.34-2.03,4.12-4.84,1.6-5.69.46-15.62-2.22-19.32-1.28-1.76-7.11-5.22-20.58-12.82-3.97-2.24-7.74-4.37-9.73-5.6,2.12-.09,4.84-.12,7.66-.14,11.65-.11,20.1-.36,22.78-2.58,2.23-1.86,2.89-12.01,1.22-18.4-.91-3.44-2.42-5.68-4.31-6.56l-26.32-15.92,26.83-2.23.53-.15c3.22-1.62,3.79-9.61,3.39-14.27-.27-3.21-1.26-8.94-4.89-11.31"
                    />
                    <path
                        d="M279.71,0c-23.51,0-43.2,17.5-43.2,39.92s19.69,40.46,43.2,40.46,42.11-17.5,42.11-40.46S302.68,0,279.71,0"
                    />
                </svg>
            </a>

            <p class="fi-filament-info-widget-version">
                <?php echo e(\Composer\InstalledVersions::getPrettyVersion('filament/filament')); ?>

            </p>
        </div>

        <div class="fi-filament-info-widget-links">
            <?php if (isset($component)) { $__componentOriginal549c94d872270b69c72bdf48cb183bc9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal549c94d872270b69c72bdf48cb183bc9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.link','data' => ['color' => 'gray','href' => 'https://filamentphp.com/docs','icon' => \Filament\Support\Icons\Heroicon::BookOpen,'iconAlias' => \Filament\View\PanelsIconAlias::WIDGETS_FILAMENT_INFO_OPEN_DOCUMENTATION_BUTTON,'rel' => 'noopener noreferrer','target' => '_blank']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'gray','href' => 'https://filamentphp.com/docs','icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(\Filament\Support\Icons\Heroicon::BookOpen),'icon-alias' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(\Filament\View\PanelsIconAlias::WIDGETS_FILAMENT_INFO_OPEN_DOCUMENTATION_BUTTON),'rel' => 'noopener noreferrer','target' => '_blank']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

                <?php echo e(__('filament-panels::widgets/filament-info-widget.actions.open_documentation.label')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal549c94d872270b69c72bdf48cb183bc9)): ?>
<?php $attributes = $__attributesOriginal549c94d872270b69c72bdf48cb183bc9; ?>
<?php unset($__attributesOriginal549c94d872270b69c72bdf48cb183bc9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal549c94d872270b69c72bdf48cb183bc9)): ?>
<?php $component = $__componentOriginal549c94d872270b69c72bdf48cb183bc9; ?>
<?php unset($__componentOriginal549c94d872270b69c72bdf48cb183bc9); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal549c94d872270b69c72bdf48cb183bc9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal549c94d872270b69c72bdf48cb183bc9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.link','data' => ['color' => 'gray','href' => 'https://github.com/filamentphp/filament','iconAlias' => \Filament\View\PanelsIconAlias::WIDGETS_FILAMENT_INFO_OPEN_GITHUB_BUTTON,'rel' => 'noopener noreferrer','target' => '_blank']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'gray','href' => 'https://github.com/filamentphp/filament','icon-alias' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(\Filament\View\PanelsIconAlias::WIDGETS_FILAMENT_INFO_OPEN_GITHUB_BUTTON),'rel' => 'noopener noreferrer','target' => '_blank']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

                 <?php $__env->slot('icon', null, []); ?> 
                    <svg viewBox="0 0 98 96" xmlns="http://www.w3.org/2000/svg">
                        <path
                            clip-rule="evenodd"
                            fill="currentColor"
                            fill-rule="evenodd"
                            d="M48.854 0C21.839 0 0 22 0 49.217c0 21.756 13.993 40.172 33.405 46.69 2.427.49 3.316-1.059 3.316-2.362 0-1.141-.08-5.052-.08-9.127-13.59 2.934-16.42-5.867-16.42-5.867-2.184-5.704-5.42-7.17-5.42-7.17-4.448-3.015.324-3.015.324-3.015 4.934.326 7.523 5.052 7.523 5.052 4.367 7.496 11.404 5.378 14.235 4.074.404-3.178 1.699-5.378 3.074-6.6-10.839-1.141-22.243-5.378-22.243-24.283 0-5.378 1.94-9.778 5.014-13.2-.485-1.222-2.184-6.275.486-13.038 0 0 4.125-1.304 13.426 5.052a46.97 46.97 0 0 1 12.214-1.63c4.125 0 8.33.571 12.213 1.63 9.302-6.356 13.427-5.052 13.427-5.052 2.67 6.763.97 11.816.485 13.038 3.155 3.422 5.015 7.822 5.015 13.2 0 18.905-11.404 23.06-22.324 24.283 1.78 1.548 3.316 4.481 3.316 9.126 0 6.6-.08 11.897-.08 13.526 0 1.304.89 2.853 3.316 2.364 19.412-6.52 33.405-24.935 33.405-46.691C97.707 22 75.788 0 48.854 0z"
                        />
                    </svg>
                 <?php $__env->endSlot(); ?>

                <?php echo e(__('filament-panels::widgets/filament-info-widget.actions.open_github.label')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal549c94d872270b69c72bdf48cb183bc9)): ?>
<?php $attributes = $__attributesOriginal549c94d872270b69c72bdf48cb183bc9; ?>
<?php unset($__attributesOriginal549c94d872270b69c72bdf48cb183bc9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal549c94d872270b69c72bdf48cb183bc9)): ?>
<?php $component = $__componentOriginal549c94d872270b69c72bdf48cb183bc9; ?>
<?php unset($__componentOriginal549c94d872270b69c72bdf48cb183bc9); ?>
<?php endif; ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $attributes = $__attributesOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $component = $__componentOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__componentOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $attributes = $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $component = $__componentOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\KOPERT-app\vendor\filament\filament\resources\views/widgets/filament-info-widget.blade.php ENDPATH**/ ?>